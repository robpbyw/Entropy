# EntropyCorrect
##Installation instructions
###install.packages("devtools") #if you have not done so already
###library(devtools)
###install_github("lloydlow/EntropyCorrect")
###library(EntropyCorrect)
###?EntropyMSA
